import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProfileService } from '../profile.service';
import { profile } from './profile.interface';

@Component({
  selector: 'app-profie',
  templateUrl: './profie.component.html',
  styleUrls: ['./profie.component.css']
})
export class ProfieComponent implements OnInit {

  alert:boolean=false

  constructor(private profile: ProfileService,private router:Router) { }

  ngOnInit(): void {
  }
  onSubmit(profile:profile){
    this.profile.addProfile(profile);
    this.alert=true;
    
  }
  onClick(){
    this.router.navigate(["/survey"]);
  }

}
