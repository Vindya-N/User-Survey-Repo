import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../login.service';
import {login} from './login.interface'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private Login: LoginService,private router:Router) { }

  ngOnInit(): void {
  }
  onLogin(login:login){
    this.Login.loginuser(login);
    this.router.navigate(["/profile"])
    // console.log(login);
    
  }
}
