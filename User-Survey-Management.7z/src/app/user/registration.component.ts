import { Component, OnInit } from '@angular/core';
import {FormGroup, FormControl, Validators}  from '@angular/forms';
import { RegisterserviceService } from '../registerservice.service';
import {register} from './register.interface'


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  alert:boolean=false
  // registrer;
  // email;
  // password;
  // display='none';
  constructor(private register: RegisterserviceService) { 
  
  }

  
  ngOnInit(){
    // this.registrer = new FormGroup({
    //   email: new FormControl("youremail@gmail.com",
    //     Validators.compose([
    //       Validators.required,
    //       Validators.pattern("[^ @]*@[^ @]*")
    //   ])),
    //   password: new FormControl('YourPassword', [
    //        Validators.minLength(8),
    //        Validators.required])
    // });
  }
  onSubmit(registration:register){
    this.register.adduser(registration);
    this.alert=true;
  }
 
//   openModalDialog(){
//     this.display='block'; //Set block css
//  }

}
