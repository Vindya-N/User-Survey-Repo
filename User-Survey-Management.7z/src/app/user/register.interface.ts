export interface register{
    
    Firstname:string;
    Lastname:string;
    mobilenumber:number;
    emailid:string;
    password:string;
}