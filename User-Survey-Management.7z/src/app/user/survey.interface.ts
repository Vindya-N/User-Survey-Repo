export interface survey{
    Title:string;
    Description:string;
    City:number;
    State:string;
    Country:string;
    Zipcode:number;
    Surveydate:Date;
}