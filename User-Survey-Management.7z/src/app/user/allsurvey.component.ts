import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { Component, OnInit,EventEmitter, Output } from '@angular/core';
import { SurveyService } from '../survey.service';
import { survey } from './survey.interface';

@Component({
  selector: 'app-allsurvey',
  templateUrl: './allsurvey.component.html',
  styleUrls: ['./allsurvey.component.css']
})
export class AllsurveyComponent implements OnInit {
  alert:boolean=false
  surveyTable:survey[];
  @Output() notifyDelete:EventEmitter<number>= new EventEmitter<number>();

  constructor(private survey: SurveyService) { }

  ngOnInit() {
    setTimeout(()=>{
      this.surveyTable=this.survey.getSurvey();
    },20);
    
  }
  onSubmit(survey:survey){
    this.survey.addSurvey(survey);
    this.surveyTable=this.survey.getSurvey();
    this.alert=true;
    
  }
  deleteRow()
  {
    
  }
}
