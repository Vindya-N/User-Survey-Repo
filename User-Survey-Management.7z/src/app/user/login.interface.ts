export interface login{
    emailid:string;
    password:string;
}