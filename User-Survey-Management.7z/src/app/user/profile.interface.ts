
export interface profile{
UserId:number;
Firstname:string;
Lastname:string;
mobilenumber:number;
emailid:string;
password:string;
}