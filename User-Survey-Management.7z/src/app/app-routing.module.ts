import { NgModule } from '@angular/core';
//import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { HomepageComponent } from './user/homepage.component';
import { LoginComponent } from './user/login.component';
import { RegistrationComponent } from './user/registration.component';
// import { HomepageComponent } from './user/homepage.component';
import { ProfieComponent } from './user/profie.component';
import { AllsurveyComponent } from './user/allsurvey.component';
// import { AppComponent } from './app.component';
const routes: Routes = [
  { path: '', component: HomepageComponent },
  { path: 'registration', component: RegistrationComponent },
 // { path: '',  redirectTo: '/some-rout', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'profile', component: ProfieComponent },
  { path: 'survey', component: AllsurveyComponent },


];

@NgModule({
  // imports: [RouterModule.forRoot(routes)],
  imports: [
    // AppComponent,
    // RegistrationComponent,
    // HomepageComponent,
    // LoginComponent,
    // ProfieComponent,
    // AllsurveyComponent,
    //CommonModule,
    RouterModule.forRoot(routes),
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
