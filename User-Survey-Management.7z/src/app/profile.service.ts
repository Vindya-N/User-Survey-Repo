import { Injectable } from '@angular/core';
import { profile } from './user/profile.interface';
import{ HttpClient} from "@angular/common/http"

@Injectable({
  providedIn: 'root'
})
export class ProfileService {

  profile:profile[];
  constructor(private http:HttpClient) { 
    this.http.get<profile[]>("assets/pro.json")
    .subscribe(data=>this.profile=data, error=>console.log(error));
  }
  addProfile(user:profile){
    this.profile.push(user);
    console.log(user);
  }
}
