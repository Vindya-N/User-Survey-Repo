import { Injectable } from '@angular/core';
import { survey } from './user/survey.interface';
import{ HttpClient} from "@angular/common/http"

@Injectable({
  providedIn: 'root'
})
export class SurveyService {

 //surveyTable:survey[];

survey:survey[];
  constructor(private http:HttpClient) {
    this.http.get<survey[]>("assets/sur.json")
    .subscribe(data=>this.survey=data, error=>console.log(error));
   }
  addSurvey(user:survey){
    this.survey.push(user);
    console.log(user);
  }
  getSurvey():survey[]{
    //console.log(this.surveyTable);
    return this.survey;
    console.log(this.survey);


  }
  
}
