import { Injectable } from '@angular/core';
import { register } from './user/register.interface';
import{ HttpClient} from "@angular/common/http"

@Injectable({
  providedIn: 'root'
})
export class RegisterserviceService {

  userregistration:register[];
  constructor(private http:HttpClient) {
    this.http.get<register[]>("assets/reg.json")
    .subscribe(data=>this.userregistration=data, error=>console.log(error));
   }
  adduser(user:register){
    this.userregistration.push(user);
    console.log(user);
  }
}
