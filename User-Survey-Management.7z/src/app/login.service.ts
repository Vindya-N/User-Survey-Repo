import { Injectable } from '@angular/core';
import { login } from './user/login.interface';
import{ HttpClient} from "@angular/common/http"

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  login:login[];
  constructor(private http:HttpClient) {
    this.http.get<login[]>(
      "assets/log.json")
    .subscribe(data=>this.login=data, error=>console.log(error));
   }
   loginuser(user:login){
    this.login.push(user);
    console.log(user);
  }

}
